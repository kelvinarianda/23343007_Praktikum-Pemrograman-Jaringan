function wajibLogin(req, res, next) {
  if (!req.session?.pengguna) return res.redirect("/login");
  next();
}

function wajibAdmin(req, res, next) {
  if (!req.session?.pengguna) return res.redirect("/login");
  if (req.session.pengguna.peran !== "admin") return res.status(403).send("Akses admin saja.");
  next();
}

module.exports = { wajibLogin, wajibAdmin };
