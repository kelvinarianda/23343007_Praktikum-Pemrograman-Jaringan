const mongoose = require("mongoose");

const SkemaPengguna = new mongoose.Schema({
  nama: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  kata_sandi_hash: { type: String, required: true },
  peran: { type: String, enum: ["admin", "user"], default: "user" },
  dibuat_pada: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Pengguna", SkemaPengguna);
