require("dotenv").config();

const express = require("express");
const http = require("http");
const path = require("path");
const session = require("express-session");
const bcrypt = require("bcrypt");
const { Server } = require("socket.io");

const { konekDatabase } = require("./config/database");
const Pengguna = require("./models/Pengguna");

// Routes
const publicRoutes = require("./routes/public");
const authRoutes = require("./routes/auth");
const dashboardRoutes = require("./routes/dashboard");
const emailRoutes = require("./routes/email");
const marketRoutes = require("./routes/marketRoutes");
const adminBeritaRoutes = require("./routes/adminBerita");

// Socket
const { pasangSocketChatbot } = require("./sockets/chatbot");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// =======================
// View Engine
// =======================
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// =======================
// Static Files
// =======================
// penting: supaya /uploads/berita/... kebaca
app.use(express.static(path.join(__dirname, "public")));

// =======================
// Body Parsers
// =======================
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// =======================
// Session
// =======================
app.use(
  session({
    secret: process.env.SESSION_SECRET || "rahasia",
    resave: false,
    saveUninitialized: false,
  })
);

// =======================
// API Routes
// =======================
app.use("/api/market", marketRoutes);

// =======================
// Web Routes
// =======================
// Catatan urutan:
// - publicRoutes untuk "/" (homepage publik)
// - auth untuk login/register
// - dashboard untuk user login
// - admin berita khusus admin
// - email untuk user login
app.use(publicRoutes);       // "/" homepage publik
app.use(authRoutes);         // /login, /register, /logout
app.use(dashboardRoutes);    // /dashboard (login required)
app.use(adminBeritaRoutes);  // /admin/berita... (admin required)
app.use(emailRoutes);        // /email/... (login required)

// =======================
// Socket
// =======================
pasangSocketChatbot(io);

// =======================
// Seed user demo (admin + user) kalau belum ada
// =======================
async function seedPenggunaDemo() {
  const adminEmail = "admin@marketbot.local";
  const userEmail = "user@marketbot.local";

  const [adaAdmin, adaUser] = await Promise.all([
    Pengguna.findOne({ email: adminEmail }),
    Pengguna.findOne({ email: userEmail }),
  ]);

  if (!adaAdmin) {
    const hash = await bcrypt.hash("admin123", 10);
    await Pengguna.create({
      nama: "Admin MarketBot",
      email: adminEmail,
      kata_sandi_hash: hash,
      peran: "admin",
    });
    console.log("✅ Seed admin: admin@marketbot.local / admin123");
  }

  if (!adaUser) {
    const hash = await bcrypt.hash("user123", 10);
    await Pengguna.create({
      nama: "User MarketBot",
      email: userEmail,
      kata_sandi_hash: hash,
      peran: "user",
    });
    console.log("✅ Seed user: user@marketbot.local / user123");
  }
}

// =======================
// Error handler (biar debug enak)
// =======================
app.use((err, req, res, next) => {
  console.error("❌ ERROR:", err);
  return res.status(500).send("Terjadi kesalahan pada server.");
});

// =======================
// Main
// =======================
async function main() {
  await konekDatabase(process.env.MONGO_URI);
  await seedPenggunaDemo();

  const port = Number(process.env.PORT || 3000);
  server.listen(port, () => console.log(`🚀 Server berjalan di http://localhost:${port}`));
}

main();
