const express = require("express");
const Berita = require("../models/Berita");
const { wajibLogin } = require("../middlewares/authMiddleware");

// kalau kamu sudah punya service market/kartu, biarkan tetap.
// ini contoh: kamu tinggal sisipkan `beritaTerbaru` saat render.

const router = express.Router();

router.get("/dashboard", wajibLogin, async (req, res) => {
  try {
    // ====== (1) ambil berita publish terbaru ======
    const beritaTerbaru = await Berita.find({ status: "publish" })
      .sort({ createdAt: -1 })
      .limit(3);

    // ====== (2) data dashboard kamu yang lama ======
    // misal: const kartu = await ...;
    // misal: const pengguna = req.session.pengguna;

    return res.render("dashboard", {
      pengguna: req.session.pengguna,
      // kartu, dll tetap
      kartu: res.locals?.kartu || [], // kalau kamu set di tempat lain, sesuaikan
      beritaTerbaru,
    });
  } catch (err) {
    console.error("Dashboard error:", err);
    return res.status(500).send("Terjadi kesalahan saat memuat dashboard.");
  }
});

module.exports = router;
