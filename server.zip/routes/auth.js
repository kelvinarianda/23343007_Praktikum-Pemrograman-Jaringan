const express = require("express");
const bcrypt = require("bcrypt");
const Pengguna = require("../models/Pengguna");

const router = express.Router();

router.get("/login", (req, res) => {
  res.render("login", { error: null });
});

router.post("/login", async (req, res) => {
  const { email, kata_sandi } = req.body || {};
  const pengguna = await Pengguna.findOne({ email });
  if (!pengguna) return res.render("login", { error: "Email tidak ditemukan." });

  const cocok = await bcrypt.compare(kata_sandi || "", pengguna.kata_sandi_hash);
  if (!cocok) return res.render("login", { error: "Kata sandi salah." });

  req.session.pengguna = { id: pengguna._id.toString(), nama: pengguna.nama, email: pengguna.email, peran: pengguna.peran };
  res.redirect("/dashboard");
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/login"));
});

module.exports = router;
